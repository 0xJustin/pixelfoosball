﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using System.Threading;
using System.IO.Ports;

public class GameManager : MonoBehaviour {

    public static GameManager gm;
    private Thread thread;
    Queue outputQueue;	// From Unity to Arduino
    Queue inputQueue;	// From Arduino to Unity
    SerialPort stream;
    public bool looping = true;
    [Header("Scene Atributtes")]
    public GameObject ball;
    public Rigidbody2D ballRB;
    public Text score;
    public Text countdown;
    public Text timeText;
    public AudioSource audio;
    public AudioClip countdownClip;
    public AudioClip countdownFinalClip;

    //theres a glitch with the particles when the ball translates
    //this is here to disable the particles when there is a goal to stop the glitch
    private ParticleSystem.EmissionModule ballParticleEmission;

    [Header("Control Vars")]
    public int p1Score;
    public int p2Score;
    private int goalLimit;
    private int timeLimit;
    private float beginTime;
    private float currentTime;
    public bool ai;
    public Color p1Color;
    public Color p2Color;
    public bool paused;
    public int difficulty;
	public void StartThread ()
    {
        outputQueue = Queue.Synchronized( new Queue() );
        inputQueue  = Queue.Synchronized( new Queue() );
        thread = new Thread (ThreadLoop);
        thread.Start();
    }

    public void SendToArduino (string command)
    {
       // Debug.Log("SEND");
        outputQueue.Enqueue(command);
    }
    public void WriteToArduino(string message) {
        Debug.Log("BAM");
        stream.Write(message);
        stream.BaseStream.Flush();
    }
    public string ReadFromArduino ()
    {
        if (inputQueue.Count == 0)
            return null;

        return (string) inputQueue.Dequeue();
    }
    public void ThreadLoop ()
    {
        // Opens the connection on the serial port
        stream = new SerialPort("/dev/cu.usbserial-AL03G22F", 9600);
        stream.ReadTimeout = 50;
        stream.Open();

        // Looping
        while (looping)
        {
            // Send to Arduino
            if (outputQueue.Count != 0)
            {
                string command = (string) outputQueue.Dequeue();
                WriteToArduino(command);
            }

            // Read from Arduino
            string result = ReadFromArduino();
            if (result != null)
                inputQueue.Enqueue(result);
        }

        stream.Close();

    }
    public void StopThread ()
    {
        lock (this)
        {
            looping = false;
        }
    }
    private void Awake() {
        gm = this;
        p1Color = MenuManager.mm.p1Color;
        p2Color = MenuManager.mm.p2Color;
        goalLimit = MenuManager.mm.goalLimitValue;
        timeLimit = MenuManager.mm.timeLimitValue;
        ai = MenuManager.mm.ai;
        difficulty = MenuManager.mm.difficulty;
        timeText.enabled = false;
        paused = false;
        beginTime = Mathf.Infinity;
        ballParticleEmission = ball.GetComponent<ParticleSystem>().emission;
        ballRB = ball.GetComponent<Rigidbody2D>();
        audio = GetComponent<AudioSource>();
        Time.timeScale = 1.0f;
        Time.fixedDeltaTime = 0.02f;
        StartGame();
    }

    public void Update() {
        //inputs
        if (Input.GetKeyDown(KeyCode.Escape) || Input.GetAxis("Quitp1") == 1)
            SceneManager.LoadScene("menuScene");
        else if (Input.GetKeyDown(KeyCode.P) || Input.GetButtonDown("Pausep1"))
            pauseUnpauseGame();

        //update time
        timeText.text = System.Math.Floor(Time.time - beginTime).ToString();
        currentTime = (float) System.Math.Floor(Time.time - beginTime);

        //ai
        if (ai)
            AIManager.processAI();

        //check if game is over
        checkGameOver();
    }

    private void checkGameOver() {
        if ((timeLimit != 0 && currentTime >= timeLimit) || (goalLimit != 0 && (p1Score == goalLimit || p2Score == goalLimit)))
            SceneManager.LoadScene("gameOverScene");
    }

    public void StartGame() {
        StartThread();
        score.enabled = false;
        ball.transform.position = new Vector2(0, -0.24f);
        p1Score = 0;
        p2Score = 0;
        StartCoroutine(Countdown());
    }

    private IEnumerator Countdown() {
        countdown.enabled = true;
        audio.volume = 0.3f;
        audio.clip = countdownClip;

        for (int i=3; i>0; i--) {
            countdown.text = i.ToString();
            audio.Play();
            yield return new WaitForSeconds(.5f);
        }

        countdown.enabled = false;
        score.enabled = true;
        audio.clip = countdownFinalClip;
        audio.Play();
        audio.volume = 1f;
        beginTime = Time.time;
        timeText.enabled = true;
        NewRound(0, 0);
    }

    public void NewRound(int player, float time) {
        ballParticleEmission.enabled = false;

        if (player == 1)
            p1Score++;
        else if (player == 2)
            p2Score++;

        string colorP1, colorP2;
        colorP1 = ColorUtility.ToHtmlStringRGB(p1Color);
        colorP2 = ColorUtility.ToHtmlStringRGB(p2Color);
        score.text = "<color=#" + colorP1 + ">" + p1Score + "</color> / " + "<color=#" + colorP2 + ">" + p2Score + "</color>";

        ball.transform.position = new Vector2(0f, -0.24f);
        ballRB.velocity = new Vector2(0f, 0f);
        Invoke("GoBall", time);
    }

    public void GoBall() {
        float x = Random.Range(0f, 1f);
        if (x <= 0.5f)
            ballRB.AddForce(new Vector2(13f, 6f));
        else ballRB.AddForce(new Vector2(-13f, -6f));

        ballParticleEmission.enabled = true;
    }

    public Color getColor(string player) {
        if (player == "p1")
            return p1Color;
        else return p2Color;
    }

    private void pauseUnpauseGame() {
        if (!paused)
            Time.timeScale = 0;
        else 
            Time.timeScale = 1;

        paused = !paused;
    }
}
