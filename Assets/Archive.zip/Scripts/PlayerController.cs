﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour {
    public int counter = 0;
    public Animator anim;
    private Rigidbody2D playerRB;
    private ParticleSystem ps;
    public string player;

    public KeyCode up;
    public KeyCode down;
    public KeyCode power;
    public bool kick;
    public float speed;
    public float kick_threshold = .5f;
    public float last_kick;
    public float kick_delta;
    public Shader shader;
    private Matrix4x4 colorMatrix {
        get {
            Matrix4x4 mat = new Matrix4x4();
            mat.SetRow(0, new Vector4(0.16f, 0.16f, 0.16f, 1f));
            Color c = GameManager.gm.getColor(player);
            mat.SetRow(2, new Vector4(c.r, c.g, c.b, c.a));
            mat.SetRow(1, new Vector4(0.51f, 0.27f, 0f, 1f));
            mat.SetRow(3, new Vector4(1f, 0.76f, 0.56f, 1f));
            return mat;
        }
    }

    // Use this for initialization
    void Start () {
        Debug.Log("BAMZ");

        anim = GetComponent<Animator>();
        anim.SetBool("kick", false);
        playerRB = GetComponent<Rigidbody2D>();
        ps = GetComponent<ParticleSystem>();

        ParticleSystem.EmissionModule emiss = ps.emission;
        emiss.enabled = false;

        setUpMaterial();
        // for (int i = 0; i < 5; i++){
        //     WriteToArduino("m 0 100\r\n", stream);
        // }
    }

    private void setUpMaterial() {
        Material mat = new Material(shader);
        mat.SetMatrix("_ColorMatrix", colorMatrix);
        GetComponent<SpriteRenderer>().material = mat;
    }

    public void Update() {
        if (player == "p1")
            anim.SetBool("kick", false);
        
        if (!(GameManager.gm.ai && player == "p2")) { //if ai is playing, ignore p2
            //movement
            //if (Input.GetKey(up) || Input.GetAxis("Vertical" + player) == -1) {
            if (Input.GetKey(up)) {
                GameManager.gm.SendToArduino("m 200 0\r");
                playerRB.velocity = new Vector2(0, speed);
            }
            else if (Input.GetKey(down) || Input.GetAxis("Vertical" + player) == 1)
                playerRB.velocity = new Vector2(0, -speed);

            else playerRB.velocity = new Vector2(0, 0);

            if ((Input.GetKeyDown(power) || Input.GetAxis("Dash" + player) == 1)) {
                anim.SetBool("kick", true);
                kick = true;
                last_kick = Time.time;
            } else {
                kick = false;
            }
            Debug.Log(kick);
        }
    }

    private void OnDrawGizmos() {
        Gizmos.color = Color.red;
    }

    private void OnTriggerEnter2D (Collider2D collision) {
        if (collision.name == "ball") {
            if (player == "p1"){
                kick_delta = Time.time - last_kick;
                Debug.Log(kick_delta);
                if (kick_delta < kick_threshold) {
                    GameManager.gm.SendToArduino("m 200 0\r");
                    Rigidbody2D ballRB = collision.GetComponent<Rigidbody2D>();
                    float x = (1f + ballRB.velocity.x / 1.5f) + (playerRB.velocity.y / 1.85f);
                    float y = (ballRB.velocity.y / 1.7f) + (playerRB.velocity.y / 1.1f);
                    ballRB.velocity = new Vector2(Math.Max(Math.Abs(x), 4.5f),y);
                }
            } else {
                anim.SetBool("kick", true);
                Rigidbody2D ballRB = collision.GetComponent<Rigidbody2D>();
                float x = (1f + ballRB.velocity.x / 1.5f) + (playerRB.velocity.y / 1.85f);
                float y = (ballRB.velocity.y / 1.7f) + (playerRB.velocity.y / 1.1f);
                ballRB.velocity = new Vector2(Math.Min(-1 * Math.Abs(x), -4.5f), y);
            }
        }
    }

    private void OnTriggerExit2D(Collider2D collision) {
        if (collision.name == "ball") {
            anim.SetBool("kick", false);
        }
    }
}